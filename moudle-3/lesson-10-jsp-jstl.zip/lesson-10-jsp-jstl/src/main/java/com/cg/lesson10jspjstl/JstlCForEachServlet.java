package com.cg.lesson10jspjstl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "jstlCForEachServlet", value = "/jstl-cforeach")
public class JstlCForEachServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Thanh", 18));
        students.add(new Student(2, "Son", 17));
        students.add(new Student(3, "cThao", 16));
        students.add(new Student(4, "Khang", 15));
        students.add(new Student(5, "Vu", 19));

        req.setAttribute("students", students);
        req.getRequestDispatcher("/jstl-cforeach.jsp").forward(req, resp);
    }
}
