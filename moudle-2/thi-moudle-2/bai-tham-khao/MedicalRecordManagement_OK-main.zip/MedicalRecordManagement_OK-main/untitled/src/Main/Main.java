package Main;

import Menu.MenuUI;

public class Main {
    public static void main(String[] args) {
        MenuUI menu = new MenuUI();
        menu.displayMenu();
    }
}