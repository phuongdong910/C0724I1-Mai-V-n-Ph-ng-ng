package main;

import management.ApplicationManager;

public class Main {
    public static void main(String[] args) {
        ApplicationManager.run();
    }
}