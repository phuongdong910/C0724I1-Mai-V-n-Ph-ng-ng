import view.ProductView;

public class Main {
    public static void main(String[] args) {
        ProductView productView = new ProductView();
        productView.renderView();
    }
}