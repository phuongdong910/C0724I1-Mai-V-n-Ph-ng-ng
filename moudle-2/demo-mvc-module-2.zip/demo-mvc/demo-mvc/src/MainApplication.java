import view.MainView;

public class MainApplication {
    public static void main(String[] args) {
        MainView mainView = new MainView();
        mainView.renderView();
    }
}